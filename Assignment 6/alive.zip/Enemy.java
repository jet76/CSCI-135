// Name        :
// Username    :
// Description :

public class Enemy
{
    // TBD: instance variables

    public Enemy(String image, 
                 double x, 
                 double y, 
                 double radius,
                 double velX, 
                 double velY)
    {
        // TBD
    }

    public String toString()
    {
        String result = "";

        // TBD
        return result;   
    }

    public void draw()
    {
        // TBD
    }

    public double getX()
    {
        // TBD    
    }

    public double getY()
    {
        // TBD    
    }

    public double getRadius()
    {
        // TBD
    }

    public void updatePos()
    {
        // TBD
    }   
}
