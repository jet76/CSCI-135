// Name        :
// Username    :
// Description :

// This is needed if you want to change the text font using StdDraw.setFont()
import java.awt.Font;

public class StayingAlive
{
    public static void main(String[] args)
    {
        // TBD        
    }

}
