// Name        :
// Username    :
// Description :

public class Player
{
    // TBD: instance variables

    public Player(String imageFilename, double x, double y, double radius, int speed)
    {
        // TBD
    }

    public void draw()
    {
        // TBD
    }

    public void updatePos(double mouseX, double mouseY)
    {
        // TBD
    }

    public boolean intersects(Enemy enemy)
    {
        // TBD
    }

    public String toString()
    {
        String result = "";
        // TBD
        return result;
    }

}
