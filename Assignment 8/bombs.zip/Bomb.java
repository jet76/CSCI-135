// Name        :
// Username    :
// Description :

// Import so we can use the java.awt.Color class
import java.awt.*;

public class Bomb
{
    // TBD: instance variables

	// Constructor, create a new bomb located at the top of the screen
	public Bomb()
	{
		// TBD
	}
	
	// Constructor, given another parent Bomb object, create a new bomblet
	// based on the parent bomb. 
	public Bomb(Bomb other, double deltaX)
	{
		// TBD
	}
	
	// Is this bomb a splitter bomb?
	public boolean isSplitter()
	{
		// TBD
		return false;
	}
	
	// Draw this bomb on the screen in the correct color based on the
	// amount of strength left for this bomb.
	public void draw()
	{
		// TBD
	}

	// Update the position of the bomb based on its velocity
	public void updatePos()
	{
		// TBD
	}
	
	// Getter method for the x-position
	public double getX()
	{
		// TBD
		return 0.0;
	}
	
	// Getter method for the y-position
	public double getY()
	{
		// TBD
		return 0.0;
	}
		
	// Getter method for the radius
	public double getRadius()
	{
		// TBD
		return 0.0;
	}
	
	// The laser has attacked this bomb.  Reduce the strength
	// of the bomb by one and return the current amount of
	// strength remaining for this bomb.  
	public int attack()
	{
		// TBD
		return 0;
	}
	
	// Given a mouse (x, y) coordinate, decide if that location
	// intersects this bomb.
	public boolean intersects(double mouseX, double mouseY)
	{
		// TBD
		return false;
	}
	
}
